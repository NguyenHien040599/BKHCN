var portalUrl = window.themeDisplay.getPortalURL();
// SSO Cổng DVC Quốc gia
var pathNameSet = "/web/cong-dich-vu-cong"
var dataObj = "";
var getSearchParams =function (prams, key) {
	let value = ""
	let headers = prams.split("&")
	headers.forEach(function (header) {
		header = header.split("=");
		let keyHeader = header[0];
		if (keyHeader === key) {
		  value = header[1]
		}
	});
	return value
};

var doChangeEmail = function(oldEmailIn, newEmailIn, techIdIn){
	if (newEmailIn) {
		$.ajax({
			url: '/o/rest/v2/dvcqgsso/changeemail?oldEmail=' + oldEmailIn + '&newEmail=' + newEmailIn + '&techId=' + techIdIn,
			data: {},
			type: 'POST',
			async: false,
			headers: {
				'groupId': window.themeDisplay.getScopeGroupId(),
				'Token': window.Liferay.authToken
			},
			success: function (result, status, xhr) {
				dataObj.state = 'auth';
				doAuth(dataObj);
				$("html").css("overflow", "");
				$("body").removeClass("fog");
				$("#updateEmail").hide();
			  var portalUrl = window.themeDisplay.getPortalURL();
				if (window.themeDisplay.isSignedIn() && (window.location.href === portalUrl + pathNameSet || window.location.href.indexOf(portalUrl + pathNameSet + '#/login-dichvucong') === 0)) {
					window.location.href = portalUrl + pathNameSet + '/dich-vu-cong'
				}
				// 
				if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + pathNameSet + '#/thu-tuc-hanh-chinh/') === 0) {
				  window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh' + window.location.hash
				}
			},
			error: function (xhr) {
			}
		})
	}
};

var doLogin = function(dataIn){
	if ($("#userNameLogin").val() && $("#passwordLogin").val()) {
		$.ajaxSetup({
			headers: {
				'groupId': window.themeDisplay.getScopeGroupId(),
				'Token': window.Liferay.authToken,
				'Authorization': 'BASIC ' + window.btoa($("#userNameLogin").val() + ":" + $("#passwordLogin").val())
			}
		});
		$.post('/o/v1/opencps/login')
		.done(function( data ) {
			if (data === 'ok') {
				$("html").css("overflow", "");
				$("body").removeClass("fog");
				$("#mappingUser").hide();
				dataIn.state = 'mapping'
				doAuth(dataIn);
				setTimeout(function () {
					window.location.reload()
				}, 100)
			} else {
				alert('Tên đăng nhập hoặc mật khẩu không chính xác')
			}
			
		})
	}
	
};
var doAuth = function(dataIn){
	$.ajaxSetup({
		headers: {
			'groupId': window.themeDisplay.getScopeGroupId(),
			'Token': window.Liferay.authToken,
			'Content-Type': 'application/json'
		}
	});
	$.post('/o/rest/v2/dvcqgsso/auth', JSON.stringify(dataIn))
	.done(function() {				
	})
};

var cancelChange = function () {
	window.location.href = window.location.origin + window.location.pathname
}
var searchParams = window.location.href.split("?");
if (searchParams[1]) {
	var dataDVCQG = decodeURIComponent(String(getSearchParams(searchParams[1], "data")));
	if (dataDVCQG) {
		dataObj = JSON.parse(atob(dataDVCQG));
		if (dataObj && dataObj.hasOwnProperty('state') && dataObj.state === 'create') {
		  var oldEmail = dataObj['ThuDienTu'] ? dataObj['ThuDienTu'] : dataObj['TechID'] + '@dvcqg.gov.vn'
			$("#newEmail").val(dataObj['ThuDienTu'] ? dataObj['ThuDienTu'] : '');
			$("html").css("overflow", "hidden !important");
			$("body").addClass("fog");
			$("#updateEmail").show();
			//show dialog
			$( "#submit" ).click(function() {
			  doChangeEmail(dataObj['TechID'] + '@dvcqg.gov.vn', $("#newEmail").val(), dataObj['TechID'])
			});
			$( "#cancel" ).click(function() {
			  $("html").css("overflow", "");
			  $("body").removeClass("fog");
			  $("#updateEmail").hide();
			  cancelChange()
			});
			return
		}
		if (dataObj && dataObj.hasOwnProperty('userId') && String(dataObj.userId) === '0' && !window.themeDisplay.isSignedIn()) {
			$("html").css("overflow", "hidden !important");
			$("body").addClass("fog");
			$("#mappingUser").show();
			//show dialog
			$( "#submitLogin" ).click(function() {
			  doLogin(dataObj)
			});
			$( "#cancelLogin" ).click(function() {
			  $("html").css("overflow", "");
			  $("body").removeClass("fog");
			  $("#mappingUser").hide();
			  cancelChange()
			});
			return
		}
	}
} else {
	
}
var portalUrl = window.themeDisplay.getPortalURL();
if (window.themeDisplay.isSignedIn() && (window.location.href === portalUrl + pathNameSet || window.location.href.indexOf(portalUrl + pathNameSet + '#/login-dichvucong') === 0)) {
	$("html").css("overflow", "");
	$("body").removeClass("fog");
	$("#mappingUser").hide();
	$("#updateEmail").hide();
	window.location.href = portalUrl + pathNameSet + '/dich-vu-cong'
}
// 
if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + pathNameSet + '#/thu-tuc-hanh-chinh/') === 0) {
	$("html").css("overflow", "");
	$("body").removeClass("fog");
	$("#mappingUser").hide();
	$("#updateEmail").hide();
  window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh' + window.location.hash
}
// end SSO DVCQG
// 
// 
if (window.themeDisplay.isSignedIn() && window.location.href === portalUrl + '/web/cong-dich-vu-cong') {
window.location.href = portalUrl + '/web/cong-dich-vu-cong/dich-vu-cong'
}
// 
if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + '/web/cong-dich-vu-cong#/thu-tuc-hanh-chinh/') === 0) {
window.location.href = 'https://dichvucong.mpi.gov.vn/web/cong-dich-vu-cong/thu-tuc-hanh-chinh' + window.location.hash
}

if (window.themeDisplay.isSignedIn() && window.location.hash.indexOf('#/add-dvc/') === 0) {
window.location.href = window.location.origin + window.location.pathname + '/dich-vu-cong/' + window.location.hash
}

//
if (window.themeDisplay.isSignedIn()) {
$("#submit-dossier").html('<a class="btn-submit" href="/web/cong-dich-vu-cong/dich-vu-cong"><i class="fa fa-bookmark" aria-hidden="true"></i> Ấn vào đây để Nộp hồ sơ trực tuyến</a>')
} else {
$("#submit-dossier").html('<a class="btn-submit" href="/web/cong-dich-vu-cong/thu-tuc-hanh-chinh"><i class="fa fa-bookmark" aria-hidden="true"></i> Ấn vào đây để Nộp hồ sơ trực tuyến</a>')
}
// Data report
var dataReport;
var yearReport = (new Date()).getFullYear();
$('.year').html("Năm " + yearReport)
var getReport = function(){
$.ajax({
    url: '/o/rest/statistics?domain=total&agency=total&month=0&year=' + yearReport,
    dataType: 'json',
    type: 'GET',
    async: false,
    headers: {
    'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): ''
    },
    success: function (result) {
    if (result.data) {
        dataReport = result.data;
        $('#count-percent').html(dataReport[0].ontimePercentage+"%")
        $('#count-received').html(dataReport[0].processCount);
        $('#count-solved').html(dataReport[0].releaseCount);
    }
    },
    error: function (xhr) {
    
    }
})

}
getReport();

// data danh sách lĩnh vực
var domainList = [];
var getDomain = function(){
    $.ajax({
        url: '/o/rest/v2/serviceinfos/statistics/domains',
        dataType: 'json',
        type: 'GET',
        async: false,
        headers: {
        'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): '',
        'Token': window.Liferay ? window.Liferay.authToken : ''
        },
        success: function (result) {
        if (result.data) {
            domainList = result.data;
            renderDomainList()
        }
        },
        error: function (xhr) {
        
        }
    })

}
function renderDomainList () {
    var htmlDomainList = ""
    for (var i = 0; i <= domainList.length - 1; i++) {
        htmlDomainList += '<li><a href="/web/cong-dich-vu-cong/thu-tuc-hanh-chinh#/thu-tuc-hanh-chinh/?domain=' +domainList[i]['domainCode'] + '">'+domainList[i]['domainName']+'</a></li>'
    }
    $('#domain-list').html(htmlDomainList)
}
getDomain();

////////////
var getAgency = function () {
    var agencyList = [
        {name: 'Chọn cơ quan', value: ''}
    ];
    var htmlAgency = '<option value="">Chọn đơn vị</option>'
    $.ajax({
        url: '/o/rest/v2/serviceinfos/statistics/agencies',
        dataType: 'json',
        type: 'GET',
        async: false,
        headers: {
            'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): '',
            'Token': window.Liferay ? window.Liferay.authToken : ''
        },
        success: function (result) {
            if (result.data) {
                agencyList = result.data;
                for (var i = 0; i <= agencyList.length - 1; i++) {
                    htmlAgency += '<option value="'+ agencyList[i]['administrationCode'] + '">' + agencyList[i]['administrationName'] + '</option>'
                }
                $('#agencySelect').html(htmlAgency)
            }
        },
        error: function (xhr) {
        
        }
    })
};
getAgency();
/////////////////////
$("#pageService").val("1")
var totalPage = 0;
var getServiceList = function(){
    var serviceList = []
    var htmlServiceList = `<tr>
        <th width="45">STT</th>
        <th>Thủ tục</th>
        <th width="150">Lĩnh vực</th>
        <th width="160">Đơn vị</th>
    </tr>`
    $.ajax({
        url: '/o/rest/v2/serviceinfos',
        dataType: 'json',
        type: 'GET',
        async: false,
        headers: {
            'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): '',
            'Token': window.Liferay ? window.Liferay.authToken : ''
        },
        data: {
            administration: $("#agencySelect").val(),
            keyword: $("#keywordSearch").val(),
            start: Number($("#pageService").val()) * 10 - 10,
            end: Number($("#pageService").val()) * 10
        },
        success: function (result) {
        if (result.data) {
        if (totalPage === 0) {
                var pageHtml = ''
                totalPage = Math.ceil(result.total / 10);
                for (var i = 1; i <= totalPage; i++) {
                    pageHtml += `<option value="${i}">${i}</option>`
                    $('#pageService').html(pageHtml)
                }
            }
            serviceList = result.data;
            for (var i = 0; i <= serviceList.length - 1; i++) {
                htmlServiceList += `
                    <tr>
                        <td>${Number($("#pageService").val()) * 10 - 10 + i + 1}</td>
                        <td><div><a href="/web/cong-dich-vu-cong/thu-tuc-hanh-chinh#/thu-tuc-hanh-chinh/${serviceList[i]['serviceInfoId']}">${serviceList[i]['serviceName']}</a></div></td>
                        <td><div>${serviceList[i]['domainName']}</div></td>
                        <td><div>${serviceList[i]['administrationName']}</div></td>
                    </tr>`
            }
            $('#contentTable').html(htmlServiceList)
        }
        },
        error: function (xhr) {
        
        }
    })
};
// getServiceList();
$("#btn-search-service").click(function(){
$("#pageService").val("1")
totalPage = 0
getServiceList();
});
$("#pageService").click(function(){
    setTimeout(function () {
        getServiceList();
    }, 200)
});

$('#domain-list').attr({'data-simplebar': '', 'data-simplebar-autohide': 'false'});

document.getElementsByClassName("year").innerHTML = new Date().getFullYear();

$( document ).ready(function() {
    console.log( "ready!" );
    $("#scroller").simplyScroll({
	  	customClass: 'vert',
        orientation: 'vertical',
        manualMode: 'loop',
        frameRate: 20,
	});
});